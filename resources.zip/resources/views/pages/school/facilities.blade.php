@extends('layouts.master')
@section('page_title', 'School Facilities')
@section('content')
<div class="container py-5">
    <div class="alert alert-info text-center">
        <h2>School Facilities</h2>
        <p>This feature is coming soon!</p>
    </div>
</div>
@endsection 