<div class="navbar navbar-expand-md navbar-dark">
    <div class="mt-2 mr-5">
        <a href="{{ route('dashboard') }}" class="d-inline-block">
            <h4 class="text-bold text-white">{{ Qs::getSystemName() }}</h4>
            @if(auth()->check() && !auth()->user()->isSuperAdmin())
                @if(auth()->user()->school)
                    <h6 class="text-white">{{ auth()->user()->school->name }}</h6>
                @else
                    <h6 class="text-danger">School not found</h6>
                @endif
            @endif
        </a>
    </div>
    {{--  <div class="navbar-brand">
        <a href="index.html" class="d-inline-block">
            <img src="{{ asset('global_assets/images/logo_light.png') }}" alt="">
        </a>
    </div> --}}

    <div class="d-md-none">
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbar-mobile">
            <i class="icon-tree5"></i>
        </button>
        <button class="navbar-toggler sidebar-mobile-main-toggle" type="button">
            <i class="icon-paragraph-justify3"></i>
        </button>
    </div>

    <div class="collapse navbar-collapse" id="navbar-mobile">
        <ul class="navbar-nav">
            <li class="nav-item">
                <a href="#" class="navbar-nav-link sidebar-control sidebar-main-toggle d-none d-md-block">
                    <i class="icon-paragraph-justify3"></i>
                </a>
            </li>


        </ul>

        <span class="navbar-text ml-md-3 mr-md-auto"></span>

        <ul class="navbar-nav">

            <li class="nav-item dropdown dropdown-user">
                <a href="#" class="navbar-nav-link dropdown-toggle" data-toggle="dropdown">
                    @auth
                        <img style="width: 38px; height:38px;" src="{{ Auth::user()->photo ?? asset('global_assets/images/placeholders/placeholder.jpg') }}" class="rounded-circle" alt="photo">
                        <span>{{ Auth::user()->name ?? 'User' }}</span>
                    @else
                        <img style="width: 38px; height:38px;" src="{{ asset('global_assets/images/placeholders/placeholder.jpg') }}" class="rounded-circle" alt="photo">
                        <span>Guest</span>
                    @endauth
                </a>

                <div class="dropdown-menu dropdown-menu-right">
                    @auth
                        <a href="{{ route('my_account') }}" class="dropdown-item"><i class="icon-cog5"></i> Account settings</a>
                        <a href="{{ route('logout') }}"
                            onclick="event.preventDefault();
                            document.getElementById('logout-form').submit();"
                            class="dropdown-item"><i class="icon-switch2"></i> Logout</a>
                        <form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
                            @csrf
                        </form>
                    @else
                        <a href="{{ route('login') }}" class="dropdown-item"><i class="icon-switch2"></i> Login</a>
                    @endauth
                </div>
            </li>
        </ul>
    </div>
</div>
